<?php

setlocale(LC_ALL, "pt-br", "pt_BR.utf-8", "pt-BR", "portuguese");
require __DIR__ . '/../../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.06 - Uma classe DateTime");


define('DATE_BR', 'd/m/Y H:i:s');

$dateNow = new DateTime();
$dateBirthday = new DateTime("1982-06-12");
$dateStatic = DateTime::createFromFormat(DATE_BR, '08/10/2022 19:00:00');

var_dump($dateNow, $dateBirthday, $dateStatic);

var_dump(
    $dateNow->format(DATE_BR),
    $dateNow->format('d')
);

echo "Hoje é dia {$dateNow->format('d')} do {$dateNow->format('F')} de {$dateNow->format('Y')}";

$newDateTimeZone = new DateTimeZone('Pacific/Apia');
$newDateTime = new DateTime("now", $newDateTimeZone);

var_dump([
    'Pacific/Apia' => $newDateTime->format(DATE_BR)
]);
die;






/*
 * [ DateTime ] http://php.net/manual/en/class.datetime.php
 */
fullStackPHPClassSession("A classe DateTime", __LINE__);


/*
 * [ DateInterval ] http://php.net/manual/en/class.dateinterval.php
 * [ interval_spec ] http://php.net/manual/en/dateinterval.construct.php
 */
fullStackPHPClassSession("A classe DateInterval", __LINE__);


/**
 * [ DatePeriod ] http://php.net/manual/pt_BR/class.dateperiod.php
 */
fullStackPHPClassSession("A classe DatePeriod", __LINE__);
