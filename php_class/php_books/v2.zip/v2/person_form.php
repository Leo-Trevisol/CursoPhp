<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Pessoas</title>
    <link rel="stylesheet" href="_css/form.css">
    <script src="_js/jquery.js"></script>
    <script src="_js/maskinput.js"></script>
    <script src="_js/script.js"></script>
</head>

<body>

    <?php
    $id = $name = $cep = $address = $district = $phone = $mail = $city = $state = null;

    if (!empty($_REQUEST['action'])) {
        $conn = mysqli_connect('localhost', 'root', '', 'books');
        //define o charset para utf8mb
        mysqli_set_charset($conn, 'utf8mb4');

        if ($_REQUEST['action'] == 'edit') {
            $id = (int)$_GET['id'];
            if (is_int($id)) {
                $query = "SELECT * FROM people WHERE id = {$id}";
                $result = mysqli_query($conn, $query);
                foreach ($result as $person) {
                    extract($person);
                }
            } else {
                echo "<div class=\"trigger trigger-error\"><b>WOOPSS!</b> Desculpa não encontramos essa pessoa em nossa base de dados. Clique para <a href=\"person_read.php\" class=\"btn btn-ligth-gray\">
        <img src='images/icons8-cancel-50.svg' style='width:25px'>
        VOLTAR</a></div>";
            }
        } elseif ($_REQUEST['action'] == 'save') {
            //UPDATE : ATUALIZAR
            if (!empty($_POST['id'])) {
                extract($_POST);
                $sql = "UPDATE people SET name = '{$name}', address = '{$address}', district = '{$district}', phone = '{$phone}', mail = '{$mail}', city = '{$city}' WHERE id = {$id} ";
                $result = mysqli_query($conn, $sql);
                //CREATE: CADASTRA NOVA PESSOA
            } else {
                $result = mysqli_query($conn, 'SELECT max(id) as next FROM people');
                $_POST['id'] = (int)mysqli_fetch_assoc($result)['next'] + 1;

                $arrInsert = [
                    'fields' => implode(', ', array_keys($_POST)),
                    'values' => "'" . implode("', '", array_values($_POST)) . "'"
                ];
                $sql = "INSERT INTO people ({$arrInsert['fields']}) VALUES ({$arrInsert['values']})";
                $result = mysqli_query($conn, $sql);
            }
            print ($result) ? '<div class="trigger trigger-sucess">Registro salvo com sucesso!</div>' : mysqli_error(
                $conn
            );
        }
    }
    ?>

    <form action="person_form.php?action=save" class="form_capitalize" method="POST" enctype="multipart/form-data">

        <label for="id"> Código</label>
        <input type="text" name="id" readonly style="width: 50%;" value="<?= $id ?>">

        <label for="name"> Nome</label>
        <input type="text" name="name" required style="width: 50%;" value="<?= $name ?>">

        <label for="name"> CEP</label>
        <input type="text" name="cep" class="wc_getCep formCep" required style="width: 50%;" value="<?= $cep ?>">

        <label for="address"> Endereço</label>
        <input type="text" name="address" class="cep_address" required style="width: 50%;" value="<?= $address ?>">

        <label for="district"> Bairro</label>
        <input type="text" name="district" class="cep_district" required style="width: 50%;" value="<?= $district ?>">

        <label for="phone"> Telefone</label>
        <input type="text" name="phone" class="formPhone" required style="width: 50%;" value="<?= $phone ?>">

        <label for="mail"> E-mail</label>
        <input type="email" name="mail" required style="width: 50%;" value="<?= $mail ?>">

        <label for="id_city"> Cidade</label>
        <input type="text" name="id_city" class="cep_city" required style="width: 50%;" value="<?= $city ?>">


        <label for="uf"> UF</label>
        <input type="text" name="state" class="cep_uf" required style="width: 50%;" value="<?= $state ?>">


        </select>
        <button class="btn btn-ligth-gray" type="submit">
            <img src="images/icons8-settings-50.svg" style="width: 25px;"> Salvar</button>

    </form>

</body>

</html>
