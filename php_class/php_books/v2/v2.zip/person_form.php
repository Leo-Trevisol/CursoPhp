<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Atualizar Pessoas</title>
    <link rel="stylesheet" href="_css/form.css">
</head>
<body>

<?php
    $id = $name = $address = $district = $phone = $mail = $id_city = null;
    if (!empty($_REQUEST['action'])) {
        $conn = mysqli_connect('localhost', 'root', '', 'books');
        //define o charset para utf8mb
        mysqli_set_charset($conn, 'utf8mb4');
        if ($_REQUEST['action'] == 'edit') {
            $id = $_GET['id'];
            $query = "SELECT * FROM person WHERE id = {$id}";
            $result = mysqli_query($conn, $query);
            foreach ($result as $person) {
                extract($person);
            }
            
        } elseif ($_REQUEST['action'] == 'save') {
            //UPDATE : ATUALIZAR
            if (!empty($_POST['id'])) {
                extract($_POST);
                $sql = "UPDATE person SET name = '{$name}', address = '{$address}', district = '{$district}', phone = '{$phone}', mail = '{$mail}', id_city = '{$id_city}' WHERE id = {$id} ";
                $result = mysqli_query($conn, $sql);
                //CREATE: CADASTRA NOVA PESSOA
            } else {
                unset($_POST['id']);
                $arrInsert = [
                    'fields' => implode(', ', array_keys($_POST)),
                    'values' => "'" . implode("', '", array_values($_POST)) . "'"
                ];
                $sql = "INSERT INTO person ({$arrInsert['fields']}) VALUES ({$arrInsert['values']})";
                $result = mysqli_query($conn, $sql);
            }
            print ($result) ? '<div class="trigger trigger-sucess">Registro salvo com sucesso!</div>' : mysqli_error(
                $conn
            );
        }
    }
?>

<form action="person_form.php?action=save" method="post" enctype="multipart/form-data">

    <label for="">Código</label>
    <input type="text" name="id" value="<?= $id ?>" readonly style="width: 30%">

    <label for="">Nome</label>
    <input type="text" name="name" value="<?= $name; ?>" required style="width: 50%">

    <label for="">Endereço</label>
    <input type="text" name="address" value="<?= $address ?>" required style="width: 50%">

    <label for="">Bairro</label>
    <input type="text" name="district" value="<?= $district ?>" required style="width: 50%">

    <label for="">Telefone</label>
    <input type="text" name="phone" value="<?= $phone ?>" required style="width: 50%">

    <label for="">E-mail</label>
    <input type="text" name="mail" value="<?= $mail ?>" required style="width: 50%">

    <label for="">Cidade</label>
    <select name='id_city' style='width: 50%'>
        <?php
            require_once 'list_cities.php';
            print list_cities($id_city);
        ?>
    </select>

    <label class="actions">
        <a href="person_read.php" class="btn btn-ligth-gray">
            <img src='images/icons8-cancel-50.svg' style='width:25px'>
            VOLTAR</a>

        <button class='btn btn-ligth-gray' type='submit'>
            <img src='images/icons8-settings-50.svg' style='width:25px'>
            SALVAR
        </button>
    </label>
</form>
</body>
</html>
